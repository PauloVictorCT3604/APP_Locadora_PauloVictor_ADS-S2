import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController, private alertCtrl: AlertController) {}

  vetor = [

    {foto:'assets/imgs/sw4.webp' , titulo:'Star Wars IV: Uma Nova Esperança', diretor:'George Lucas', anodelancamento: '1977', tempo:'02:01:00', preco:"20,00", status: 'disponível'},
    {foto:'assets/imgs/hob.webp' , titulo:'O Hobbit: Uma Jornada Inesperada', diretor:'Peter Jackson', anodelancamento: '2012', tempo:'02:49:00', preco:"23,00", status: 'disponível'},
    {foto:'assets/imgs/pac.jpeg' , titulo:'Circulo De Fogo', diretor:'Guillermo del Toro', anodelancamento: '2013', tempo:'02:11:00', preco:"15,00", status: 'disponível'}

  ];

  maisInformacoes(item){

    const alert = this.alertCtrl.create({

      title:item.titulo,
      message: `
      <b>Diretor: ${item.diretor} <br>
      <b>Ano de Lançamento: ${item.anodelancamento} <br>
      <b>Duração: ${item.tempo} <br>
      <b>Preço: ${item.preco} <br>
      <b>Status:</b> ${item.status === 'disponível' ? 'Disponível' : 'Alugado'}
      `,
      buttons: [{
        text: 'Cancelar',
        role: 'cancel',  
        handler: () => {
          console.log('Cancelar clicado');
        }
      },
      {
        text: item.status === 'disponível' ? 'Alugar' : 'Devolver',
        handler: () => {
          this.toggleStatus(item);
        }
      }
    ]
  });

    alert.present();
  }

  toggleStatus(item) {
    if (item.status === 'disponível') {
      item.status = 'alugado';
    } else {
      item.status = 'disponível';
    }
  }

  excluir(item){
    console.log('excluir', item);

    for (let i = 0; i < this.vetor.length; i++) {
      const element = this.vetor[i];

      if(element.titulo == item.titulo){

        this.vetor.splice(i, 1)

      }
    }
  }

  confirmarExclusao(item) {
    const confirm = this.alertCtrl.create({
      title: 'Excluir filme',
      message: 'Deseja realmente excluir esse filme do catálogo?',
      buttons: [
        {
          text: 'Não',
          handler: () => {
            console.log('Disagree clicked');
          }
        },
        {
          text: 'Sim',
          handler: () => {
            console.log('Agree clicked');
            this.excluir(item)
          }
        }
      ]
    });
    confirm.present();
  }

  adcionarFilme() {
    const prompt = this.alertCtrl.create({
      title: 'Adiconar filme a catálogo',
      inputs: [
        {
          name: 'titulo',
          placeholder: 'Titulo'
        },
        {
          name: 'diretor',
          placeholder: 'Diretor do filme'
        },
        {
          name: 'anolancamento',
          placeholder: 'Ano de lançamento'
        },
        {
          name: 'tempo',
          placeholder: 'Duração do filme'
        },
        {
          name: 'preco',
          placeholder: 'Insira valor do alguel do filme'
        },
        {
          name: 'foto',
          placeholder: 'URL da capa do filme'
        },
      ],
      buttons: [
        {
          text: 'Cancelar',
          handler: data => {
            console.log('cancelado!');
          }
        },
        {
          text: 'Adicionar',
          handler: data => {
            console.log('clicado!', data);
          
            let a = {foto:data.foto, titulo:data.titulo, diretor:data.diretor, lancamento:data.anodelancamento, tempo:data.tempo, preco:data.preco, status:'disponível'};
            this.vetor.push(data);

          }
        }
      ]
    });
    prompt.present();
  }

}